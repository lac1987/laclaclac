const express = require('express')
const app = express();

const bodyParser = require('body-parser')
const cookieParser = require('cookie-parser');
const logger = require('morgan');

app.use(logger('dev'));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(express.json());

app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));

const routes = require('./route/PostRoute')

app.use('/', routes)

module.exports = app;