const mongoose = require('mongoose');
mongoose.set('useFindAndModify', false)
const Posts = mongoose.model('posts')


exports.baseRoute = async (req,res) => {
    res.send('server running')
}

exports.getPosts = async (req,res) => {
    const posts = await Posts.find()
    res.json(posts)
}



exports.createPost = async (req,res) => {
    await new Posts(req.body).save((err, data) =>
    {
        if (err) {
            res.status(500).json({
                message: "somthing went wrong please try again"
        })
        }else{
            res.status(200).json({
                message: "post created",
                data,

            })
        }
    })
    
}

exports.getSinglePost = async (req, res) => {
    let postID= req.params.id;
    await Posts.findById({_id: postID}, (err,data) =>{
        if(err) {
            res.status(500).json({
                message: "something went wrong, please try again"
            })
        }else{
            console.log(data);
            res.status(200).json ({
                message: "post was found",
                data,
            })
        }
    })

}

exports.updatePost = async (req, res) => {
    let postID= req.params.id;
    await Posts.findByIdAndUpdate({_id: postID}, {$set : req.body}, (err,data) =>{
        if(err) {
            res.status(500).json({
                message: "something went wrong, please try again"
            })
        }else{
            res.status(200).json({
                message: "post updated",
                data,
            })
        }
    })
}

exports.deletePost = async (req,res) => {
    let postID =req.params.id;
    await Posts.deleteOne({_id: postID}, (err,data) =>{
        if(err) {
            res.status(500).json({
                message: "something went wrong, please try again"
            })
        }else{
            res.status(200).json({
                message: "post deleted"
            })
        }
    })
}