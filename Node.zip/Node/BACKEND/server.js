const mongoose = require('mongoose');

require('dotenv').config({ path: '.env'})

mongoose.connect(process.env.DATABASE,
    {
        useUnifiedTopology: true,
        useNewUrlParser: true
    })

mongoose.Promise = global.Promise;
mongoose.connection.on('error', (err) =>{
    console.error (`database connection error ${err.message}`)
})

require('./Model/Post')

const app = require('./app');

const server = app.listen(1987, () =>{
    console.log(`express running PORT${server.address().port}`);
})