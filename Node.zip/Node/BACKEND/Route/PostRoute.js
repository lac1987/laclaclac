
const express = require('express')
const router = express.Router();

const postController = require('../Controller/PostController')

// use
router.get('/', postController.baseRoute)
// read all
router.get('/getposts', postController.getPosts);
// read one
router.get('/getposts/:id', postController.getSinglePost);
// create
router.post('/create', postController.createPost);
//update
router.put('/post/:id/update', postController.updatePost);
//delete
router.delete('/delete/:id', postController.deletePost)


module.exports = router;