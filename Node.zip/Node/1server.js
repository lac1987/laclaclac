const express = require('express');
const app = express();

app.use(express.json());

const courses = [
    { id: 1, name: 'Information technology'},
    { id: 2, name: 'Computer Engineer'},
    { id: 3, name: 'Computer Science'},

]; 

app.get('/', (req, res) => {
    res.send('hello world');
});

app.get('/see/courses', (req, res) => {
    res.send(courses);
});

app.post('/see/courses', (req, res) => {
    const course = {
        id: courses.length + 1,
        name: req.body.name
    };
    courses.push(course);
    res.send(course);
});



app.get('/see/courses/:id', (req,res) => {
    const course = courses.find(c => c.id === parseInt(req.params.id));
    if (!course) res.status(404).send('course not found');
    res.send(course);
});

const port = process.env.PORT || 8000;
app.listen(port, () => console.log(`Listening on port ${port}`));